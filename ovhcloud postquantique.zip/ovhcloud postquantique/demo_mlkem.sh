#!/usr/bin/env bash
set -euo pipefail

# Ce script démontre une encapsulation/décapsulation ML-KEM-768 avec OpenSSL 3.5+.
# Il crée tous les fichiers dans un répertoire temporaire supprimé automatiquement.

workdir="$(mktemp -d)"
trap 'rm -rf "$workdir"' EXIT
cd "$workdir"

# Génère une paire de clés ML-KEM-768 puis exporte la clé publique.
openssl genpkey -algorithm ML-KEM-768 -out mlkem768.pem
openssl pkey -in mlkem768.pem -pubout -out mlkem768_pub.pem

# Encapsule un secret partagé avec la clé publique.
openssl pkeyutl -encap \
  -inkey mlkem768_pub.pem \
  -pubin \
  -out ciphertext.bin \
  -secret shared_secret.bin

# Décapsule le secret avec la clé privée.
openssl pkeyutl -decap \
  -inkey mlkem768.pem \
  -in ciphertext.bin \
  -secret decapsulated_secret.bin

# Vérifie que les deux secrets sont identiques sans afficher leur contenu.
if cmp -s shared_secret.bin decapsulated_secret.bin; then
  echo "Succès : le secret encapsulé et le secret décapsulé sont identiques."
else
  echo "Échec : les secrets diffèrent." >&2
  exit 1
fi

# Affiche uniquement des tailles de fichiers pour illustrer l'expérience.
wc -c ciphertext.bin shared_secret.bin decapsulated_secret.bin
