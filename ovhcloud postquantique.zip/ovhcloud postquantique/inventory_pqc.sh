#!/usr/bin/env bash
set -euo pipefail

# Vérifie que la commande OpenSSL est disponible.
command -v openssl >/dev/null 2>&1 || {
  echo "OpenSSL est introuvable dans le PATH." >&2
  exit 1
}

# Affiche la version afin de vérifier que l'environnement utilise OpenSSL 3.5 ou supérieur.
echo "== Version OpenSSL =="
openssl version

echo
echo "== KEM post-quantiques disponibles =="
# Liste les mécanismes d'encapsulation de clés fournis par les providers actifs.
openssl list -kem-algorithms | grep -E 'ML-KEM|MLKEM' || true

echo
echo "== Signatures post-quantiques disponibles =="
# Liste les algorithmes de signature ML-DSA et SLH-DSA.
openssl list -signature-algorithms | grep -E 'ML-DSA|SLH-DSA' || true

echo
echo "== Groupes TLS 1.3 liés à ML-KEM =="
# Liste les groupes TLS 1.3 hybrides ou purement post-quantiques disponibles.
openssl list -tls1_3 -tls-groups | grep -E 'MLKEM|ML-KEM' || true
