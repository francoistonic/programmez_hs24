#!/usr/bin/env bash
set -euo pipefail

# Teste un serveur TLS 1.3 avec une préférence pour le groupe hybride X25519MLKEM768.
# Usage : ./tls_hybrid_probe.sh exemple.org 443

host="${1:-}"
port="${2:-443}"

if [[ -z "$host" ]]; then
  echo "Usage : $0 <hôte> [port]" >&2
  exit 1
fi

# X25519 reste en second choix afin de permettre une comparaison ou un repli classique.
# Le résultat dépend du support du serveur, du client et des équipements intermédiaires.
printf '' | openssl s_client \
  -connect "${host}:${port}" \
  -servername "$host" \
  -tls1_3 \
  -groups X25519MLKEM768:X25519 \
  2>&1 | grep -E 'Protocol|Cipher|Negotiated|Server Temp Key|group' || true
