import marshal
import dis

with open("__pycache__/mod.cpython-313.pyc", "rb") as f:
    header = f.read(16)  # skip .pyc header (size depends on version)
    code_obj = marshal.load(f)

dis.dis(code_obj)
