# (not so) complex module that provides helper functions
# for squaring and summing integers


# return the sum of the squares of two integers
def sum_square(a, b: int) -> int:
    return a * a + b * b


def square(a: int) -> int:
    return a * a
