import pyc_mod


def main():
    print("Hello World!")
    print(mod.sum_square(2, 3))
    print(mod.square(2))


if __name__ == "__main__":
    main()
