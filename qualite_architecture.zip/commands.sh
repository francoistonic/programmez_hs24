#!/bin/sh
# Commandes de l'article : installation et analyse avec AST Metrics

brew install ast-metrics/tap/ast-metrics
ast-metrics analyze --report-html=rapport ./src

# ou, sans installation :
npx ast-metrics analyze --report-html=rapport ./src
pipx run ast-metrics analyze --report-html=rapport ./src
