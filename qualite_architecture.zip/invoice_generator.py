from cart.cart import Cart
from discount.discount_policy import DiscountPolicy
from tax.tax_calculator import TaxCalculator


class InvoiceGenerator:
    def total(self, cart: Cart, code: str | None) -> float:
        total = 0.0

        for item in cart.items():
            if item.quantity <= 0:
                continue

            price = item.unit_price

            if item.is_discountable:
                if code is not None:
                    price -= DiscountPolicy.apply(price, code)

            total += price * item.quantity

        return total + TaxCalculator.vat(total)
